from django.contrib import admin
from .models import Author, ArticleGroup, Article, ArticleGallery

admin.site.register(Author)
admin.site.register(ArticleGroup)
admin.site.register(Article)
admin.site.register(ArticleGallery)