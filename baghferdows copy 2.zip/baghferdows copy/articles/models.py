from django.db import models
from django.contrib.auth.models import User

# نویسنده مقاله
class Author(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

# گروه مقاله
class ArticleGroup(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

# مقاله
class Article(models.Model):
    group = models.ForeignKey(ArticleGroup, on_delete=models.SET_NULL, null=True)
    author = models.ForeignKey(Author, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=250)
    main_image = models.ImageField(upload_to='articles/')
    summary = models.TextField()
    content = models.TextField()
    keywords = models.CharField(max_length=250)
    created_at = models.DateTimeField(auto_now_add=True)
    published_at = models.DateTimeField(blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    pdf_file = models.FileField(upload_to='articles/pdf/', blank=True, null=True)
    view_count = models.IntegerField(default=0)
    references = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.title

# گالری تصاویر مقاله
class ArticleGallery(models.Model):
    article = models.ForeignKey(Article, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='articles/gallery/')
    title = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.title or f"تصویر {self.id} از {self.article.title}"