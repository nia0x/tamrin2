from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

from .models import History, VisitProgram, Memory, Gallery
from .forms import MemoryForm, ContactForm


def signup(request):
    """
    ثبت‌نام کاربران جدید
    بعد از ثبت‌نام، کاربر وارد سایت می‌شود و به صفحه home هدایت می‌شود
    """
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # ورود خودکار بعد از ثبت‌نام
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'core/signup.html', {'form': form})


@login_required
def home(request):
    """
    صفحه اصلی باغ فردوس:
    - نمایش تاریخچه
    - برنامه بازدید
    - خاطرات کاربران
    - گالری تصاویر
    - فرم اضافه کردن خاطره (اگر کاربر لاگین باشد و POST ارسال شود)
    """
    history = History.objects.first()
    programs = VisitProgram.objects.all()
    memories = Memory.objects.all().order_by('-created_at')  # جدیدترین‌ها اول
    galleries = Gallery.objects.all()

    # پردازش فرم اضافه کردن خاطره
    if request.method == 'POST' and request.user.is_authenticated:
        form = MemoryForm(request.POST, request.FILES)
        if form.is_valid():
            memory = form.save(commit=False)
            memory.user = request.user
            memory.save()
            form = MemoryForm()  # فرم خالی بعد از ثبت
    else:
        form = MemoryForm()

    context = {
        'history': history,
        'programs': programs,
        'memories': memories,
        'galleries': galleries,
        'form': form
    }

    return render(request, 'core/home.html', context)


@login_required
def add_memory(request):
    """
    ویو ثبت خاطره مستقل (اگر بخواهید صفحه جداگانه برای اضافه کردن خاطره)
    """
    if request.method == 'POST':
        form = MemoryForm(request.POST, request.FILES)
        if form.is_valid():
            memory = form.save(commit=False)
            memory.user = request.user
            memory.save()
            return redirect('home')
    else:
        form = MemoryForm()
    return render(request, 'core/add_memory.html', {'form': form})


def contact(request):
    """
    فرم تماس با ما
    بعد از ارسال، کاربر به صفحه اصلی هدایت می‌شود
    """
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  
    else:
        form = ContactForm()

    return render(request, 'core/contact.html', {'form': form})


def redirect_to_login(request):
    """
    هدایت کاربران به صفحه لاگین هنگام ورود به "/"
    """
    from django.urls import reverse
    return redirect(reverse('login'))