from django.contrib import admin
from .models import History, VisitProgram, Memory, Gallery
from .models import Gallery

from .models import ContactMessage
admin.site.register(ContactMessage)

admin.site.register(History)
admin.site.register(VisitProgram)
admin.site.register(Memory)
admin.site.register(Gallery)