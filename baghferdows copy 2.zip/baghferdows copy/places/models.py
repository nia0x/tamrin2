from django.db import models

class Place(models.Model):
    code = models.CharField(max_length=20, unique=True)
    title = models.CharField(max_length=200)
    description = models.TextField()
    main_image = models.ImageField(upload_to='places/')
    visit_day = models.CharField(max_length=50)
    visit_time = models.CharField(max_length=50)
    rules = models.TextField()
    is_active = models.BooleanField(default=True)


    def __str__(self):
        return self.title


class VisitorType(models.Model):
    code = models.IntegerField(unique=True)
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Ticket(models.Model):
    place = models.ForeignKey(Place, on_delete=models.CASCADE)
    visitor_type = models.ForeignKey(VisitorType, on_delete=models.CASCADE)
    price = models.IntegerField()

    def __str__(self):
        return f"{self.place.title} - {self.visitor_type.name} : {self.price} تومان"
    


class PlaceGallery(models.Model):
    place = models.ForeignKey(Place, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='places/gallery/')
    title = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self):
        return self.title or f"تصویر {self.id} از {self.place.title}"
    

