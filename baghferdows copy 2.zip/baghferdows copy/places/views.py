from django.shortcuts import render, get_object_or_404
from .models import Place, Ticket

def place_list(request):
    places = Place.objects.all()
    return render(request, 'core/place_list.html', {'places': places})


def place_detail(request, place_id):
    place = get_object_or_404(Place, id=place_id)
    tickets = Ticket.objects.filter(place=place)
    return render(request, 'core/place_detail.html', {
        'place': place,
        'tickets': tickets
    })