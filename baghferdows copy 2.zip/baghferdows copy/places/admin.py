from django.contrib import admin
from .models import Place, VisitorType, Ticket

from .models import PlaceGallery
admin.site.register(PlaceGallery)

admin.site.register(Place)
admin.site.register(VisitorType)
admin.site.register(Ticket)