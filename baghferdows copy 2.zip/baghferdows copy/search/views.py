from django.shortcuts import render
from articles.models import Article
from places.models import Place
from django.db.models import Q
from places.models import Place

def search_results(request):
    query = request.GET.get('q', '')

    # جستجو در مقالات
    articles = Article.objects.filter(is_active=True).filter(
        Q(title__icontains=query) |
        Q(summary__icontains=query) |
        Q(content__icontains=query) |
        Q(keywords__icontains=query)
    )

    # جستجو در مکان‌ها
    places = Place.objects.filter(is_active=True).filter(
        Q(title__icontains=query) | 
        Q(description__icontains=query)
    )

    context = {
        'query': query,
        'articles': articles,
        'places': places,
    }

    return render(request, 'core/search_results.html', context)